*Welcome to Easy-Play*

Thank you for downloading Easy-Play

I started working on Easy-Play when I was 14 back in 2018. I finished it so I think it will be cool
to share this Software with the you.

*****Please read this Document carefully!*****



Easy-Play uses Parts of other Software:

Easy-Play is coded in Autohotkey and uses youtube-dl to download Music from Youtube.
it also uses ffmpeg and vc redist x86.
These 3 Programs will be downloaded during the installation.

If any owner of these 3 Programs has an Problem with this contact marcel.d04@outlook.de.





Safety / Windows Defender and Antivirus Detection:

This Software is completely contains no Malware Adware etc. Easy-Play is completely free and safe.
If you try to run the Installer or Easy-Play a Window popped up with "Windows protected your PC".
This is completely normal: Windows doesnt know Easy-Play so it will be blocked.

Just click more information and click "Run anyway" or "trotzdem ausführen"
If you still think Easy-Play is not safe or you need some support write an Mail to marcel.d04@outlook.de.
I will help you.

Please do not sell this Program or rename it and say that it is yours.

Kaze#6991

Marcel :)